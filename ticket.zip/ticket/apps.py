from django.apps import AppConfig


class TicketConfig(AppConfig):
    name = 'ticket'
    verbose_name = 'ماژول تیکت'
